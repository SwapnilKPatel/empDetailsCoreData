//
//  AddTaskVC.swift
//  EmployeeDetails_CoreData
//
//  Created by Megha Patel on 11/01/19.
//  Copyright © 2019 Megha Patel. All rights reserved.
//

import UIKit

class AddTaskVC: UIViewController, UITextFieldDelegate, UIPickerViewDelegate, UIPickerViewDataSource {

    
    @IBOutlet weak var taskIdLbl: UILabel! 
    @IBOutlet weak var taskNameTxt:UITextField!
    @IBOutlet weak var taskAssignTxt: UITextField!
    
    @IBOutlet weak var taskDatePickerView: UIDatePicker!
    @IBOutlet weak var taskDueDateTxt: UITextField!
    @IBOutlet weak var datePickerView: UIDatePicker!
   
    
    @IBOutlet weak var catagoryPicker: UIPickerView!
    @IBOutlet weak var catagoryPickerView: UIPickerView!
    @IBOutlet weak var catagoryTxt: UITextField!
    
    @IBOutlet weak var detailTextView: UITextView!
    @IBOutlet weak var toolBar: UIToolbar!    
    @IBOutlet weak var validationMsgLbl: UILabel!
    
    
    var task: Task?
    var isEditClick = Bool()
    
    var catagoryArray = ["a","b","c","d","e","f","g"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        taskDatePickerView.isHidden = true
        catagoryPickerView.isHidden = true
        toolBar.isHidden = true
        
        //Set current date as minimun date
        let currentDate = NSDate()
        datePickerView.minimumDate = currentDate as Date
        datePickerView.date = currentDate as Date
        
        if isEditClick {
            
        taskIdLbl.text = task?.id
        
        taskNameTxt.text = task?.name
        taskAssignTxt.text = task?.assignTo
        taskDueDateTxt.text = task?.dueDate
        catagoryTxt.text = task?.catagory
        detailTextView.text = task?.detail
        
        }else{
            
            //Rendom Task ID
            let num = String(arc4random_uniform(11111))
            taskIdLbl.text = "\(num)"
            
        }
        
        validationMsgLbl.isHidden = true
        
    }
    
    //Set textfield text length
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
       
        let currentString: NSString = taskNameTxt.text! as NSString
        let newString: NSString =
            currentString.replacingCharacters(in: range, with: string) as NSString
        return newString.length <= 30
        
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        
        return 1
        
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        return catagoryArray.count
        
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        return catagoryArray[row]
        
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        

        
    }
    
    @IBAction func toolBarCancelBtnClick(_ sender: Any) {
        
         taskDatePickerView.isHidden = true
         catagoryPickerView.isHidden = true
         toolBar.isHidden = true
        
    }
    
    @IBAction func toolBarDoneBtnClick(_ sender: Any) {
        
         taskDatePickerView.isHidden = true
         catagoryPickerView.isHidden = true
         toolBar.isHidden = true
        
        
            let formatter = DateFormatter()
            formatter.dateFormat = "dd-MM-yyyy"
            taskDueDateTxt.text = formatter.string(from:
                taskDatePickerView.date)
       
                // Get Index
                let selectedRow = catagoryPickerView.selectedRow(inComponent: 0)
                //Index data
                catagoryTxt.text = catagoryArray[selectedRow]
        
    }
    
    @IBAction func taskDueDateButtonClick(_ sender: UIButton) {
        
        if taskDatePickerView.isHidden{
            
            taskDatePickerView.isHidden = false
            toolBar.isHidden = false
            
        }else{
            
            taskDatePickerView.isHidden = true
            toolBar.isHidden = true
        }
        
    }
    
    @IBAction func taskCatagoryButtonClick(_ sender: UIButton) {
        
        if catagoryPickerView.isHidden{
            
            catagoryPickerView.isHidden = false
            toolBar.isHidden = false
            
        }else{
            
            catagoryPickerView.isHidden = true
            toolBar.isHidden = true
            
        }
        catagoryPickerView.reloadAllComponents()
    }
    
    @IBAction func saveButtonClick(_ sender: UIButton) {
        
        if isEditClick == false {
        
            guard let name = taskNameTxt.text, taskNameTxt.text?.characters.count != 0
                
                else{
                    
                    validationMsgLbl.isHidden = false
                    validationMsgLbl.text = "Enter Task"
                    return
            }
            
            guard let assignTo = taskAssignTxt.text, taskAssignTxt.text?.characters.count != 0
                
                else{
                    
                    validationMsgLbl.isHidden = false
                    validationMsgLbl.text = "Enter Task Assign To"
                    return
            }
            
            guard let dueData = taskDueDateTxt.text, taskDueDateTxt.text?.characters.count != 0
                
                else{
                    
                    validationMsgLbl.isHidden = false
                     validationMsgLbl.text = "Enter Task DueDate"
                    return
            }
            
            guard let catagory = catagoryTxt.text, catagoryTxt.text?.characters.count != 0
               
                else{
                    
                    validationMsgLbl.isHidden = false
                    validationMsgLbl.text = "Enter Task Catagory"
                    return
            }
            
            guard let detail = detailTextView.text, detailTextView.text?.characters.count != 0
                
                else{
                    
                    validationMsgLbl.isHidden = false
                    validationMsgLbl.text = "Enter Task Details"
                    return
            }
            
            let taskDict = ["id":taskIdLbl.text,"name":taskNameTxt.text,"assignTo":taskAssignTxt.text,"dueData":taskDueDateTxt.text,"catagory":catagoryTxt.text,"detail":detailTextView.text]
        
                Task.save(object: taskDict as! [String : String])
        
                self.navigationController?.popViewController(animated: true)
        }else{
            
            guard let name = taskNameTxt.text, taskNameTxt.text?.characters.count != 0
                
                else{
                    
                    validationMsgLbl.isHidden = false
                    validationMsgLbl.text = "Enter Task"
                    return
            }
            
            guard let assignTo = taskAssignTxt.text, taskAssignTxt.text?.characters.count != 0
                
                else{
                    
                    validationMsgLbl.isHidden = false
                    validationMsgLbl.text = "Enter Task Assign To"
                    return
            }
            
            guard let dueData = taskDueDateTxt.text, taskDueDateTxt.text?.characters.count != 0
                
                else{
                    
                    validationMsgLbl.isHidden = false
                    validationMsgLbl.text = "Select Task DueDate"
                    return
            }
            
            guard let catagory = catagoryTxt.text, catagoryTxt.text?.characters.count != 0
                
                else{
                    
                    validationMsgLbl.isHidden = false
                    validationMsgLbl.text = "Select Task Catagory"
                    return
            }
            
            guard let detail = detailTextView.text, detailTextView.text?.characters.count != 0 
                
                else{
                    
                    validationMsgLbl.isHidden = false
                    validationMsgLbl.text = "Enter Task Details"
                    return
            }
            
            let taskDict = ["id":taskIdLbl.text,"name":taskNameTxt.text,"assignTo":taskAssignTxt.text,"dueData":taskDueDateTxt.text,"catagory":catagoryTxt.text,"detail":detailTextView.text]
            
                Task.update(taskDict: taskDict as! [String:String])
            
                self.navigationController?.popViewController(animated: true)
            
        }
        
    }
       
}
