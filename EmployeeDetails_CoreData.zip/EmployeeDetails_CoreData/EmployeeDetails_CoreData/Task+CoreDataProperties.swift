//
//  Task+CoreDataProperties.swift
//  EmployeeDetails_CoreData
//
//  Created by Megha Patel on 11/01/19.
//  Copyright © 2019 Megha Patel. All rights reserved.
//
//

import Foundation
import CoreData
import UIKit


extension Task {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Task> {
        return NSFetchRequest<Task>(entityName: "Task")
    }

    @NSManaged public var name: String?
    @NSManaged public var assignTo: String?
    @NSManaged public var dueDate: String?
    @NSManaged public var catagory: String?
    @NSManaged public var detail: String?
    @NSManaged public var id: String?

}
