//
//  Task+CoreDataClass.swift
//  EmployeeDetails_CoreData
//
//  Created by Megha Patel on 11/01/19.
//  Copyright © 2019 Megha Patel. All rights reserved.
//
//

import Foundation
import CoreData
import UIKit

class Task: NSManagedObject {
    
    static func save(object:[String:String]){
        
        let contex = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext
      
        let task = NSEntityDescription.insertNewObject(forEntityName: "Task", into: contex!) as! Task
        
        
        task.name = object["name"]
        task.assignTo = object["assignTo"]
        task.dueDate = object["dueData"]
        task.catagory = object["catagory"]
        task.detail = object["detail"]
        task.id = object["id"]
        
        do{
            try contex?.save()
            
            print("\(task)")
        }catch{
            print("Data not save!!!")
        }
        
    }
    
   static func getTaskData() -> [Task]{
        
        let contex = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext
        
        var task = [Task]()
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Task")
        
        do{
            task = try contex?.fetch(fetchRequest) as! [Task]
            
        }catch{
            print("Can not get Data")
        }
        return task
    }
    
    static func deleteData(index:Int) -> [Task]{
       
        let contex = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext
        
        var task = getTaskData()
        contex?.delete(task[index])
        task.remove(at: index)
        
        do{
            try contex?.save()
        }catch{
            print("Can not Delete Task!!!")
        }
        return task
    }
    
    static func update(taskDict:[String:String]){
        
        let contex = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext
        
        var task = [Task]()
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Task")
        fetchRequest.predicate = NSPredicate(format: "SELF.id like %@", taskDict["id"] as! String)
        
        do{
            task = try contex?.fetch(fetchRequest) as! [Task]
            
            if task.count > 0 {
                
                let task = task[0]
                
                task.name = taskDict["name"]
                task.assignTo = taskDict["assignTo"]
                task.dueDate = taskDict["dueData"]
                task.catagory = taskDict["catagory"]
                task.detail = taskDict["detail"]
                task.id = taskDict["id"]
                
            }
            print("\(task)")
        }catch{
            print("could not found data")
        }

        do{
            try contex?.save()
            print("Data Updated... :) ")
        }catch{
            print("Data not Updated!!!")
        }

    }

}
