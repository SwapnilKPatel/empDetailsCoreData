//
//  AddEmployeeVC.swift
//  EmployeeDetails_CoreData
//
//  Created by Megha Patel on 03/01/19.
//  Copyright © 2019 Megha. All rights reserved.
//

import UIKit

class AddEmployeeVC: UIViewController, UIPickerViewDelegate,UIPickerViewDataSource {
    
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var nameTxt: UITextField!
    @IBOutlet weak var surNameTxt: UITextField!
    @IBOutlet weak var employeeNumberTxt: UITextField!
    @IBOutlet weak var mobileNumberTxt:UITextField!
   
    @IBOutlet weak var addressLbl: UILabel!
    
    @IBOutlet weak var addressView: UITextView!
    
    @IBOutlet var datePickerView: UIDatePicker!
    @IBOutlet weak var datePickerLbl: UILabel!
    @IBOutlet weak var datePickerBtnClicked: UIButton!
    
    @IBOutlet var agePickerView: UIPickerView!
    @IBOutlet weak var agePickerLbl: UILabel!
    @IBOutlet weak var agePickerBtnClicked: UIButton!
    
    @IBOutlet weak var toolBar: UIToolbar!
    
    var employee: Employee?
    var isEditClick = Bool()
    
    var ageArray = ["22","23","24","25","26","27","28","29","30","31","33","34","35","36","37","38","39","40","41","42","43","44","45","46","47","48","49","50","51","52","53","54","55","56","57","58","59","60"]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if isEditClick == true {
            
            title = "Edit Employee"
            
        }else{
            
            title = "Add Employee"
          
         //Set Navigation Button
            navigationItem.leftBarButtonItem = UIBarButtonItem(barButtonSystemItem: .cancel, target: self, action: #selector(self.backButtonClick))
            
        }
       
        toolBar.isHidden = true
        
    //For Scroll View
        scrollView.contentSize = CGSize(width: 375, height: 590)
        
        datePickerView.backgroundColor = #colorLiteral(red: 0.8277135491, green: 0.9567983747, blue: 0.9537551999, alpha: 1)
        datePickerView.setValue(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 1), forKey:"textColor")
        
        //Random number
        if isEditClick {
         
            employeeNumberTxt.text = employee?.employee_number
                
        //Fill Data
            nameTxt.text = employee?.name
            surNameTxt.text = employee?.surname
            mobileNumberTxt.text = employee?.mobile_number
            addressView.text = employee?.address
            datePickerLbl.text = employee?.birthdate
            agePickerLbl.text = employee?.age
            
        }else{
            // For Random Number
                let num = String(arc4random_uniform(1111111))
                employeeNumberTxt.text = "\(num)"
        
        }
       
    }

    @objc func backButtonClick(){
        
        dismiss(animated: true, completion: nil)
   
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        
        return 1
        
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        return ageArray.count
        
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
      
        return ageArray[row]
   
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
    }
    
    @IBAction func birthDateBtnClick(_ sender: Any) {
        
        if datePickerView.isHidden {
            datePickerView.isHidden = false
            toolBar.isHidden = false
            
        }else{
            datePickerView.isHidden = true
            toolBar.isHidden = true
        }
        
    }
    
    @IBAction func ageBtnClick(_ sender: Any) {
        
        
        if agePickerView.isHidden {
            agePickerView.isHidden = false
            toolBar.isHidden = false
            
        }else{
            agePickerView.isHidden = true
            toolBar.isHidden = true
        }
        agePickerView.reloadAllComponents()
        
    }
   
    @IBAction func saveBtnClick(_ sender: Any) {
        
        if(isEditClick == false){
        
            // Add new detail
            let dict = ["name": nameTxt.text, "surname": surNameTxt.text, "employee_number": employeeNumberTxt.text, "mobile_number": mobileNumberTxt.text, "birthdate": datePickerLbl.text, "age": agePickerLbl.text, "address": addressView.text] as [String : Any]
      
                EmployeeModel.shareInstance.save(object: dict as! [String : Any])
    
                self.dismiss(animated: true, completion: nil)
        
        }else{

            //2. Update detail
            let dict = ["name": nameTxt.text, "surname": surNameTxt.text, "employee_number": employeeNumberTxt.text, "mobile_number": mobileNumberTxt.text, "birthdate": datePickerLbl.text, "age": agePickerLbl.text, "address": addressView.text] as [String : Any]
            
            EmployeeModel.shareInstance.update(employeeDict: dict as! [String : Any])
           
             self.navigationController?.popViewController(animated: true)
        }
        
    }
    
    @IBAction func toolBarDone(_ sender: UIBarButtonItem) {
        
            datePickerView.isHidden = true
            agePickerView.isHidden = true
            toolBar.isHidden = true
        
        //Get Index
        let selectedRow = agePickerView.selectedRow(inComponent: 0)
        //Index data
          agePickerLbl.text = ageArray[selectedRow] 
        
       
        let formatter = DateFormatter()
        formatter.dateFormat = "dd-MM-yyyy"
        datePickerLbl.text = formatter.string(from: datePickerView.date)
        
    }
    
    @IBAction func toolBarCancel(_ sender: UIBarButtonItem) {
        
            datePickerView.isHidden = true
            agePickerView.isHidden = true
            toolBar.isHidden = true
        
    }
   
}
