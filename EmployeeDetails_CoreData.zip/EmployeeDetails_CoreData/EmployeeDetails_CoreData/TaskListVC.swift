//
//  TaskListVC.swift
//  EmployeeDetails_CoreData
//
//  Created by Megha Patel on 11/01/19.
//  Copyright © 2019 Megha Patel. All rights reserved.
//

import UIKit

class TaskListVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var taskTable: UITableView!
    @IBOutlet weak var addTaskImg: UIImageView!
    @IBOutlet weak var addTaskButton: UIButton!
    @IBOutlet weak var textLbl: UILabel!
    
    var taskData = [Task]()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        taskData = Task.getTaskData()
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(self.addNewTackButtonClick(_:)))
        
        let nib = UINib(nibName: "TaskDetailCell", bundle: nil)
        taskTable.register(nib, forCellReuseIdentifier: "TaskDetailCell")

    }
    
    override func viewWillAppear(_ animated: Bool) {
       
        taskData = Task.getTaskData()
        taskTable.reloadData()
        
        if taskData.count == 0 {
            
            taskTable.isHidden = true
            addTaskImg.isHidden = false
            addTaskButton.isHidden = false
            textLbl.isHidden = false
            
        }else{
            
            taskTable.isHidden = false
            addTaskImg.isHidden = true
            addTaskButton.isHidden = true
            textLbl.isHidden = true
            
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return taskData.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 157
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TaskDetailCell", for: indexPath) as! TaskDetailCell
        
            cell.idLbl.text = taskData[indexPath.row].id
            cell.taskNameLbl.text = taskData[indexPath.row].name
            cell.dueDateLbl.text = taskData[indexPath.row].dueDate
            cell.taskDetailLbl.text = taskData[indexPath.row].detail
            cell.categoryLbl.text = taskData[indexPath.row].catagory
            cell.assignToLbl.text = taskData[indexPath.row].assignTo
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        
        let delete = UIContextualAction(style: .destructive, title: "Delete") { (action, view, nil) in
            
            self.taskData = Task.deleteData(index: indexPath.row)
            self.taskTable.deleteRows(at: [indexPath], with: .automatic)
            
            self.taskTable.reloadData()
            
        }
        delete.backgroundColor = #colorLiteral(red: 1, green: 0.1491314173, blue: 0, alpha: 1)
        
        let edit = UIContextualAction(style: .normal, title: "Edit") { (action, view, nil) in
            
            
            let vc = AddTaskVC(nibName: "AddTaskVC", bundle: nil)
                vc.isEditClick = true
            
            //Data Pass
            let pass = self.taskData[indexPath.row] as! Task
            vc.task = pass
           
            self.navigationController?.pushViewController(vc, animated: true)
            
        }
        edit.backgroundColor = #colorLiteral(red: 0, green: 0.5898008943, blue: 1, alpha: 1)
        
        // Delete and edit button fixed swipe
        let config = UISwipeActionsConfiguration(actions: [delete,edit])
        config.performsFirstActionWithFullSwipe = false
        return config
        
        
    }
    
    @IBAction func addNewTackButtonClick(_ sender: Any) {
       
        let obj = AddTaskVC(nibName: "AddTaskVC", bundle: nil)
        
        self.navigationController?.pushViewController(obj, animated: true)
        
    }
    
}
