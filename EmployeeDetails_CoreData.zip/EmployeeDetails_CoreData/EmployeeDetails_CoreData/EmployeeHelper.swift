//
//  Employee.swift
//  EmployeeDetails_CoreData
//
//  Created by Megha Patel on 04/01/19.
//  Copyright © 2019 Megha. All rights reserved.
//

import Foundation
import CoreData
import UIKit

class EmployeeModel {
    
    static var shareInstance = EmployeeModel()
    
    let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext
    
    func save(object:[String:Any]){
        
        let employee = NSEntityDescription.insertNewObject(forEntityName: "Employee", into: context!) as! Employee
        
        employee.name = object["name"] as? String
        employee.surname = object["surname"] as? String
        employee.employee_number = object["employee_number"] as? String
        employee.mobile_number = object["mobile_number"] as? String
        employee.birthdate = object["birthdate"] as? String
        employee.age = object["age"] as? String
        employee.address = object["address"] as? String
    
        do{
            try context?.save()
            print("Data Saved :) ")
        }catch{
            print("Data not save!!!")
        }
        
    }
    
    func getEmployeeData() -> [Employee]{
        var employees = [Employee]()
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Employee")
        do{
            employees = try context?.fetch(fetchRequest) as! [Employee]

            print("\(employees)")
        }catch{
            print("Could not found Data!!!")
        }
        return employees
    }
    
    func deleteEmployeeData(index:Int) -> [Employee]{
        var employees = getEmployeeData()
        context?.delete(employees[index])
        employees.remove(at: index)
        do{
            try context?.save()
        }catch{
            print("cannot dalete Data")
        }
        return employees
    }
    
    func update(employeeDict:[String:Any]){
        
        var employees = [Employee]()
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Employee")
        fetchRequest.predicate = NSPredicate(format: "SELF.employee_number like %@", employeeDict["employee_number"] as! String)
        do{
            employees = try context?.fetch(fetchRequest) as! [Employee]
            
            if employees.count > 0 {
                
                let employee = employees[0]
                
                employee.name = employeeDict["name"] as? String
                employee.surname = employeeDict["surname"] as? String
                employee.employee_number = employeeDict["employee_number"] as? String
                employee.mobile_number = employeeDict["mobile_number"] as? String
                employee.birthdate = employeeDict["birthdate"] as? String
                employee.age = employeeDict["age"] as? String
                employee.address = employeeDict["address"] as? String
                
            }
            print("\(employees)")
        }catch{
            print("Could not found Data!!!")
        }

        
        do{
            try context?.save()
            print("Data Updated... :) ")
        }catch{
            print("Data not Updated!!!")
        }
        
    }
}
