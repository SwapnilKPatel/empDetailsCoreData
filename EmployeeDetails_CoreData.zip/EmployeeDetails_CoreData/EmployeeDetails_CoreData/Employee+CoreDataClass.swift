//
//  Employee+CoreDataClass.swift
//  EmployeeDetails_CoreData
//
//  Created by Megha Patel on 03/01/19.
//  Copyright © 2019 Megha. All rights reserved.
//
//

import Foundation
import CoreData


public class Employee: NSManagedObject {

}
