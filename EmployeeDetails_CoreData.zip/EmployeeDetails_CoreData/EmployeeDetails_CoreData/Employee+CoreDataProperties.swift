//
//  Employee+CoreDataProperties.swift
//  EmployeeDetails_CoreData
//
//  Created by Megha Patel on 03/01/19.
//  Copyright © 2019 Megha. All rights reserved.
//
//

import Foundation
import CoreData


extension Employee {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Employee> {
        return NSFetchRequest<Employee>(entityName: "Employee")
    }

    @NSManaged public var name: String?
    @NSManaged public var surname: String?
    @NSManaged public var employee_number: String?
    @NSManaged public var mobile_number: String?
    @NSManaged public var age: String?
    @NSManaged public var birthdate: String?
    @NSManaged public var address: String?

}
