//
//  EmployeeListVC.swift
//  EmployeeDetails_CoreData
//
//  Created by Megha Patel on 03/01/19.
//  Copyright © 2019 Megha. All rights reserved.
//

import UIKit

class EmployeeListVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
   
    @IBOutlet weak var employeeTable: UITableView!
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var addBtn: UIButton!
    @IBOutlet weak var addDataImage: UIImageView!
    
    @IBOutlet weak var menuView: UIView!
    @IBOutlet weak var tableViewMenu: UITableView!
    @IBOutlet weak var menuImageView: UIImageView!
   
    var employees = [Employee]()
   
    var menuData = ["Empl List","Task List","Filter"]
    
    var isMenuOpen = Bool()
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
             title = "Employee List"
        
        //get data from Employee
        employees = EmployeeModel.shareInstance.getEmployeeData()
        
            let button: UIButton = UIButton(type: UIButtonType.custom)
            button.setImage(UIImage(named: "menu1.png"), for: UIControlState.normal)
            button.addTarget(self, action: "openMenuButton", for: UIControlEvents.touchUpInside)
            button.frame = CGRect(x: 0, y: 30, width: 30, height: 30)
            let barButton = UIBarButtonItem(customView: button)
             self.navigationItem.leftBarButtonItem = barButton
        
        
        //navigation button
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(self.addButtonClick))
       
        let nib = UINib(nibName: "TableViewCell", bundle: nil)
        employeeTable.register(nib, forCellReuseIdentifier: "EmployeeCell")
       
    }
    
    override func viewWillAppear(_ animated: Bool) {
     
        
      menuView.frame = CGRect(x: 0, y: 60, width: 0, height: 607)
        
      employees = EmployeeModel.shareInstance.getEmployeeData()
      employeeTable.reloadData()
        
        if employees.count == 0{
            
            label.isHidden = false
            addBtn.isHidden = false
            addDataImage.isHidden = false
            employeeTable.isHidden = true
            
        }else{
            
            label.isHidden = true
            addBtn.isHidden = true
            addDataImage.isHidden = true
            employeeTable.isHidden = false
            
        }

    }
    
    @IBAction func openMenuButton(){
        
        if isMenuOpen {
    
            isMenuOpen = false
            
            UIView.animate(withDuration: 0.3, animations: {
                
                self.menuView.frame = CGRect(x: 0, y: 60, width: 0, height: 607)
                self.view.layoutIfNeeded()
            })
            
        }else{
            
            isMenuOpen = true
            
            UIView.animate(withDuration: 0.3, animations: {
            
                self.menuView.frame = CGRect(x: 0, y: 60, width: 232, height: 607)
                
                self.view.layoutIfNeeded()
            })
        }
      
    }
    
    @objc @IBAction func addButtonClick(){

        let obj = AddEmployeeVC(nibName: "AddEmployeeVC", bundle: nil)

        let navController = UINavigationController(rootViewController: obj)
        self.present(navController, animated: true, completion: nil)

    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if tableView == employeeTable
        {
            return employees.count
        }else{
            return menuData.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
       
        if tableView == employeeTable {
        
            let cell = tableView.dequeueReusableCell(withIdentifier: "EmployeeCell", for: indexPath) as! TableViewCell

        let employee = employees[indexPath.row] as! Employee
        
        cell.nameLbl.text = employee.name
        cell.surnameLbl.text = employee.surname
        cell.employeeNumberLbl.text = employee.employee_number
        cell.mobileLbl.text = employee.mobile_number
        cell.birthDateLbl.text = employee.birthdate
        cell.ageLbl.text = employee.age
        cell.addressLbl.text = employee.address
       
            return cell

        }else{
         
            var cell  = tableView.dequeueReusableCell(withIdentifier: "Cell") as? UITableViewCell
            
            if (cell == nil) {
                cell = UITableViewCell(style: UITableViewCellStyle.value1, reuseIdentifier: "Cell")
            }
            
            cell?.textLabel?.text = menuData[indexPath.row]
            

            return cell!

        }
    }
    
    //For Cell Height
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        if tableView == employeeTable
        {
            return 130.0
        }else{
            return 70.0
        }
    }
    
    //Create Delete and Edit button in Swipecell right to left
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        
      
                    let delete = UIContextualAction(style: .destructive, title: "Delete") { (action, view, nil) in

                    self.employees = EmployeeModel.shareInstance.deleteEmployeeData(index: indexPath.row)
                    self.employeeTable.deleteRows(at: [indexPath], with: .automatic)

                    self.employeeTable.reloadData()
                    
                }
                delete.backgroundColor = #colorLiteral(red: 1, green: 0.1491314173, blue: 0, alpha: 1)

                let edit = UIContextualAction(style: .normal, title: "Edit") { (action, view, nil) in
                    
                
                let vc = AddEmployeeVC(nibName: "AddEmployeeVC", bundle: nil)
                    vc.isEditClick = true
                    
                    //Data Pass
                    let emp = self.employees[indexPath.row] as! Employee
                    vc.employee = emp
                    
                self.navigationController?.pushViewController(vc, animated: true)
                
                }
                edit.backgroundColor = #colorLiteral(red: 0, green: 0.5898008943, blue: 1, alpha: 1)

                // Delete and edit button fixed(swipe)
                    let config = UISwipeActionsConfiguration(actions: [delete,edit])
                    config.performsFirstActionWithFullSwipe = false
                    return config
            
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        UIView.animate(withDuration: 0.3, animations: {
            
            self.menuView.frame = CGRect(x: 0, y: 60, width: 0, height: 607)
            self.view.layoutIfNeeded()
        })
        
        if indexPath.row == 0
        {
            let obj = EmployeeListVC(nibName: "EmployeeListVC", bundle: nil)
            
            self.navigationController?.pushViewController(obj, animated: true)
        }
        
        if indexPath.row == 1
        {
            let obj = TaskListVC(nibName: "TaskListVC", bundle: nil)
            self.navigationController?.pushViewController(obj, animated: true)
        }
    }
    
}
